let i=[{id:1,title:"文山特區美食節",description:"匯聚文山特區最受歡迎的美食店家，提供限時優惠和特色料理",content:`文山特區美食節即將開跑！

🎉 活動時間：2024年1月15日 - 1月31日
📍 活動地點：文山特區商圈

🍽️ 參與店家：
• 文山牛肉麵 - 招牌紅燒牛肉麵8折
• 老街豆花 - 買二送一
• 夜市小吃 - 滿200送50
• 星巴克 - 第二杯半價

🎁 特別優惠：
• 消費滿500元送精美小禮物
• 打卡分享送飲料券
• 會員專享額外9折優惠

歡迎大家踴躍參與，一起品嚐文山特區的美味！`,start_date:"2024-01-15T00:00:00Z",end_date:"2024-01-31T23:59:59Z",is_active:!0,created_at:new Date().toISOString(),updated_at:new Date().toISOString()},{id:2,title:"週末市集活動",description:"每週六日舉辦的市集，提供新鮮農產品和手工藝品",content:`文山特區週末市集

🕐 活動時間：每週六日 09:00-18:00
📍 活動地點：文山特區廣場

🥬 農產品區：
• 新鮮有機蔬菜
• 當季水果
• 在地農特產

🎨 手工藝品區：
• 手作飾品
• 文創商品
• 藝術作品

🎪 現場活動：
• 親子DIY體驗
• 音樂表演
• 美食試吃

歡迎全家大小一起來逛市集！`,start_date:"2024-01-06T09:00:00Z",end_date:"2024-12-31T18:00:00Z",is_active:!0,created_at:new Date().toISOString(),updated_at:new Date().toISOString()},{id:3,title:"會員專屬優惠月",description:"專為會員設計的特別優惠活動",content:`會員專屬優惠月

👑 活動時間：2024年2月1日 - 2月29日
🎯 活動對象：文山特區會員

💎 會員專享優惠：
• 全店商品9折優惠
• 生日當月額外8折
• 免費停車3小時
• 專屬客服熱線

🎁 新會員福利：
• 註冊即送100元購物金
• 首次消費滿300送50
• 免費會員卡製作

📱 如何成為會員：
1. 下載文山特區APP
2. 填寫基本資料
3. 完成註冊即可享受優惠

立即註冊，享受專屬優惠！`,start_date:"2024-02-01T00:00:00Z",end_date:"2024-02-29T23:59:59Z",is_active:!0,created_at:new Date().toISOString(),updated_at:new Date().toISOString()},{id:4,title:"春節特別活動",description:"慶祝農曆新年的特別慶祝活動",content:`文山特區春節特別活動

🧧 活動時間：2024年2月10日 - 2月17日
🎊 活動主題：龍年大吉，文山特區賀新春

🎆 精彩活動：
• 舞龍舞獅表演
• 傳統年貨市集
• 春聯書法體驗
• 猜燈謎遊戲

🎁 特別優惠：
• 全店商品85折
• 滿額送紅包袋
• 消費抽獎活動
• 免費停車5小時

🍽️ 年菜預訂：
• 多間餐廳提供年菜外帶
• 提前預訂享9折優惠
• 免費配送到府

祝大家新年快樂，龍年行大運！`,start_date:"2024-02-10T00:00:00Z",end_date:"2024-02-17T23:59:59Z",is_active:!1,created_at:new Date().toISOString(),updated_at:new Date().toISOString()}];async function r(){return await new Promise(t=>setTimeout(t,300)),[...i].sort((t,e)=>new Date(e.created_at).getTime()-new Date(t.created_at).getTime())}async function o(t){await new Promise(n=>setTimeout(n,500));const e={id:Math.max(...i.map(n=>n.id))+1,title:t.title||"",description:t.description||"",content:t.content||"",start_date:t.start_date||new Date().toISOString(),end_date:t.end_date||new Date().toISOString(),is_active:t.is_active??!0,created_at:new Date().toISOString(),updated_at:new Date().toISOString()};return i.push(e),e}async function c(t,e){await new Promise(a=>setTimeout(a,500));const n=i.findIndex(a=>a.id===t);if(n===-1)throw new Error("活動不存在");const d={...i[n],...e,id:t,updated_at:new Date().toISOString()};return i[n]=d,d}async function s(t){await new Promise(n=>setTimeout(n,300));const e=i.findIndex(n=>n.id===t);if(e===-1)throw new Error("活動不存在");i.splice(e,1)}export{o as mockCreateActivity,s as mockDeleteActivity,r as mockGetActivities,c as mockUpdateActivity};
