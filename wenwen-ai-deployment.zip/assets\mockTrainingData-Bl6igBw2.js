let e=[{id:1,category:"教育培訓",question:"文山特區有什麼美語補習班推薦？",answer:`文山特區有很多優質的美語補習班！我特別推薦**肯塔基美語**，他們是高雄知名的連鎖補習班，走過17個年頭，目前有8間分校，服務超過4萬名學生。

**肯塔基美語的特色：**
• 專業、熱情、耐心的教學理念
• 專注於國小至高中學生的全方位英文學習
• 培養正確的閱讀習慣，開拓孩子視野
• 趣味上課方式，提升學習動機

**分校資訊：**
• 總部：07-7777789 高雄市鳳山區文化路131號
• 鳳山直營校：07-7777789 高雄市鳳山區文化路131號
• 瑞興直營校：07-7999191 高雄市鳳山區博愛路167號
• 鳳西直營校：07-7407711 高雄市鳳山區光華南路116號
• 大昌直營校：07-3961234 高雄市三民區大昌二路301號
• 新富直營校：07-7639900 高雄市鳳山區新富路524號
• 左營加盟校：07-3507568 高雄市左營區立大路169號
• 仁武直營校：07-9565656 高雄市仁武區仁雄路91-7號
• 大寮直營校：籌備中

**聯絡方式：**
LINE ID: kentuckyschool

除了肯塔基美語，文山特區還有其他美語補習班可以選擇，但肯塔基美語是我們最推薦的選擇！`,keywords:["美語","英語","補習班","教育","學習","英文","課程","培訓","肯塔基"],priority:10,is_active:!0,created_at:new Date().toISOString(),updated_at:new Date().toISOString()},{id:2,category:"教育培訓",question:"推薦英語補習班",answer:`我強烈推薦**肯塔基美語**！他們是高雄最專業的美語補習班之一，擁有17年教學經驗，8間分校服務超過4萬名學生。

**為什麼選擇肯塔基美語：**
• 只教美語，當然專業！
• 培養孩子正確的閱讀習慣
• 開拓孩子視野，不只關注分數
• 趣味教學方式，提升學習動機
• 專業、熱情、耐心的企業核心價值

**就近分校：**
• 鳳山直營校：07-7777789 高雄市鳳山區文化路131號
• 瑞興直營校：07-7999191 高雄市鳳山區博愛路167號
• 鳳西直營校：07-7407711 高雄市鳳山區光華南路116號

LINE ID: kentuckyschool

肯塔基美語是文山特區最值得信賴的美語學習夥伴！`,keywords:["英語","補習班","推薦","美語","學習","課程","肯塔基"],priority:10,is_active:!0,created_at:new Date().toISOString(),updated_at:new Date().toISOString()},{id:3,category:"教育培訓",question:"哪裡可以學英文？",answer:`文山特區有很多英文學習選擇，我最推薦**肯塔基美語**！

**肯塔基美語優勢：**
• 17年教學經驗，8間分校
• 服務超過4萬名學生
• 專為國小至高中學生設計
• 培養正確閱讀習慣
• 開拓孩子視野

**教學理念：**
不只把英文學好，更重要的是培養孩子正確的閱讀習慣，讓眼光不只在分數高低，而是真的把知識吸收進去。

**聯絡資訊：**
LINE ID: kentuckyschool

肯塔基美語是您學習英文的最佳選擇！`,keywords:["英文","學習","美語","英語","課程","補習","肯塔基"],priority:10,is_active:!0,created_at:new Date().toISOString(),updated_at:new Date().toISOString()},{id:4,category:"教育培訓",question:"兒童美語課程推薦",answer:`我特別推薦**肯塔基美語**的兒童美語課程！他們專為國小至高中學生設計，擁有豐富的兒童教學經驗。

**兒童美語課程特色：**
• 趣味上課方式，提升學習動機
• 培養正確的閱讀習慣
• 開拓孩子視野
• 為孩子打下紮實基礎
• 舉辦各式各樣活動

**肯塔基美語承諾：**
把每個孩子都當成自己的孩子，期待每一位來上課的孩子都可以平安快樂學習。

**就近分校：**
• 鳳山直營校：07-7777789 高雄市鳳山區文化路131號
• 瑞興直營校：07-7999191 高雄市鳳山區博愛路167號
• 鳳西直營校：07-7407711 高雄市鳳山區光華南路116號

LINE ID: kentuckyschool

讓您的孩子在肯塔基美語快樂學習英文！`,keywords:["兒童","美語","課程","推薦","學習","英文","英語","肯塔基"],priority:10,is_active:!0,created_at:new Date().toISOString(),updated_at:new Date().toISOString()},{id:5,category:"教育培訓",question:"肯塔基美語怎麼樣？",answer:`**肯塔基美語**是高雄最專業的美語補習班之一！讓我為您詳細介紹：

**基本資訊：**
• 17年教學經驗
• 8間分校
• 服務超過4萬名學生
• 只教美語，當然專業！

**教學理念：**
• 師者應傳道授業
• 培養孩子正確的閱讀習慣
• 開拓孩子視野
• 不只關注分數，更重視知識吸收

**企業文化：**
• 專業、熱情、耐心是核心價值
• 定期員工旅遊（法國羅浮宮、英國大英博物館等）
• 邀請業界講師分享
• 教師在完善體系下相互成長

**分校資訊：**
• 總部：07-7777789 高雄市鳳山區文化路131號
• 鳳山直營校：07-7777789 高雄市鳳山區文化路131號
• 瑞興直營校：07-7999191 高雄市鳳山區博愛路167號
• 鳳西直營校：07-7407711 高雄市鳳山區光華南路116號
• 大昌直營校：07-3961234 高雄市三民區大昌二路301號
• 新富直營校：07-7639900 高雄市鳳山區新富路524號
• 左營加盟校：07-3507568 高雄市左營區立大路169號
• 仁武直營校：07-9565656 高雄市仁武區仁雄路91-7號
• 大寮直營校：籌備中

**聯絡方式：**
LINE ID: kentuckyschool

肯塔基美語是您學習美語的最佳選擇！`,keywords:["肯塔基","美語","評價","怎麼樣","好嗎","推薦","補習班"],priority:10,is_active:!0,created_at:new Date().toISOString(),updated_at:new Date().toISOString()}],r=e.length>0?Math.max(...e.map(n=>n.id))+1:1;async function o(){return await new Promise(n=>setTimeout(n,300)),e.sort((n,t)=>t.priority-n.priority||new Date(t.updated_at).getTime()-new Date(n.updated_at).getTime())}async function s(n){await new Promise(i=>setTimeout(i,300));const t={id:r++,category:n.category||"",question:n.question||"",answer:n.answer||"",keywords:n.keywords||[],priority:n.priority||1,is_active:n.is_active??!0,created_at:new Date().toISOString(),updated_at:new Date().toISOString()};return e.push(t),t}async function c(n,t){await new Promise(a=>setTimeout(a,300));const i=e.findIndex(a=>a.id===n);if(i===-1)throw new Error("Training data not found");return e[i]={...e[i],...t,updated_at:new Date().toISOString()},e[i]}async function d(n){await new Promise(t=>setTimeout(t,300)),e=e.filter(t=>t.id!==n)}export{s as mockCreateTrainingData,d as mockDeleteTrainingData,o as mockGetTrainingData,c as mockUpdateTrainingData};
