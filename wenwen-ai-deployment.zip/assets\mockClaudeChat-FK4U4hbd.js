import{getStoresByCategory as g,getPartnerStores as S}from"./mockStores-CdDU_mPV.js";async function I(t,y,$){await new Promise(n=>setTimeout(n,1e3));const d=["英語","美語","補習班","教育","學習","英文","課程","培訓","肯塔基"],l=["美食","餐廳","小吃","料理","餐飲","吃","喝"],m=["停車","停車場","車位"],f=d.some(n=>t.includes(n)),u=l.some(n=>t.includes(n)),_=m.some(n=>t.includes(n));let r="GENERAL",i=.5,s=[],o=[],a="";console.log("模擬聊天 - 消息:",t),f?(r="ENGLISH_LEARNING",i=.9,s=d.filter(n=>t.includes(n)),a=`我超推薦**肯塔基美語**的啦！✨ 他們真的是文山特區最專業的美語補習班，17年教學經驗，8間分校服務超過4萬名學生。只教美語，當然專業！相信我，選他們就對了～

**肯塔基美語特色：** 🎓
- 培養孩子正確的閱讀習慣，開拓孩子視野
- 不只關注分數，更重視知識吸收
- 專業、熱情、耐心的企業核心價值

**分校資訊：** 📍
- 鳳山直營校：07-7777789 高雄市鳳山區文化路131號
- 瑞興直營校：07-7999191 高雄市鳳山區博愛路167號
- 鳳西直營校：07-7407711 高雄市鳳山區光華南路116號
- 大昌直營校：07-3961234 高雄市三民區大昌二路301號
- 新富直營校：07-7639900 高雄市鳳山區新富路524號
- 左營加盟校：07-3507568 高雄市左營區立大路169號
- 仁武直營校：07-9565656 高雄市仁武區仁雄路91-7號

**聯絡方式：** LINE ID: kentuckyschool

肯塔基美語真的是文山特區最推薦的美語學習選擇！有什麼問題都可以問我喔～ 😊`,o=[{id:1,name:"肯塔基美語",category:"教育培訓",is_partner:!0}]):u?(r="FOOD",i=.8,s=l.filter(e=>t.includes(e)),o=g("美食餐廳").slice(0,3).map(e=>({id:e.id,name:e.store_name,category:e.category,is_partner:e.is_partner_store||!1})),a=`嘿～文山特區有很多不錯的美食選擇呢！🍱 我推薦以下幾家：

${o.map((e,c)=>`${c+1}. **${e.name}** ${e.is_partner?"[特約商家]":""}
   ${e.category}`).join(`
`)}

這些都是我蠻推薦的店家，有空不妨去試試看！如果有其他想了解的，也可以問我喔～ 😊`):_?(r="PARKING",i=.8,s=m.filter(e=>t.includes(e)),o=g("停車場").slice(0,3).map(e=>({id:e.id,name:e.store_name,category:e.category,is_partner:e.is_partner_store||!1})),a=`停車的話，文山特區有幾個不錯的選擇：🅿️

${o.map((e,c)=>`${c+1}. **${e.name}**
   地址請洽詢管理單位`).join(`
`)}

記得確認營業時間和收費標準喔！如果有其他問題也可以問我～ 😊`):(r="GENERAL",i=.6,s=["推薦","介紹"],o=S().slice(0,2).map(e=>({id:e.id,name:e.store_name,category:e.category,is_partner:!0})),a=`讓我為你推薦一些不錯的選擇：✨

${o.map((e,c)=>`${c+1}. **${e.name}** [特約商家]
   ${e.category}`).join(`
`)}

希望對你有幫助！如果有其他需求，也可以再問我沒關係！😊`);const p=y||crypto.randomUUID();return{response:a,session_id:p,intent:r,confidence:i,recommended_stores:o,debug:{isFollowUp:!1,matchedKeywords:s,storeCount:o.length,engine:"mock-v1.0"},version:"WEN 1.3.0-MOCK",sessionId:p,timestamp:new Date().toISOString()}}export{I as mockSendMessage};
