import{getStoresByCategory as d,searchStores as f}from"./mockStores-DB9RDcAC.js";async function S(e,l,h){await new Promise(i=>setTimeout(i,1e3));const $=["英語","美語","補習班","教育","學習","英文","課程","培訓","肯塔基"].some(i=>e.includes(i));if(console.log("模擬聊天 - 消息:",e),console.log("模擬聊天 - 是否英語相關:",$),$)return{response:`我超推薦**肯塔基美語**的啦！✨ 他們真的是文山特區最專業的美語補習班，17年教學經驗，8間分校服務超過4萬名學生。只教美語，當然專業！相信我，選他們就對了～

**肯塔基美語特色：** 🎓
- 培養孩子正確的閱讀習慣，開拓孩子視野
- 不只關注分數，更重視知識吸收
- 專業、熱情、耐心的企業核心價值

**分校資訊：** 📍
- 鳳山直營校：07-7777789 高雄市鳳山區文化路131號
- 瑞興直營校：07-7999191 高雄市鳳山區博愛路167號
- 鳳西直營校：07-7407711 高雄市鳳山區光華南路116號
- 大昌直營校：07-3961234 高雄市三民區大昌二路301號
- 新富直營校：07-7639900 高雄市鳳山區新富路524號
- 左營加盟校：07-3507568 高雄市左營區立大路169號
- 仁武直營校：07-9565656 高雄市仁武區仁雄路91-7號

**聯絡方式：** LINE ID: kentuckyschool

肯塔基美語真的是文山特區最推薦的美語學習選擇！有什麼問題都可以問我喔～ 😊`,sessionId:l||crypto.randomUUID(),timestamp:new Date().toISOString()};let c="";if(e.includes("餐廳")||e.includes("美食")||e.includes("吃")){const i=d("美食餐廳"),n=i.filter(o=>o.is_partner_store),t=i.filter(o=>!o.is_partner_store);c=`文山特區有很多超棒的美食選擇！我為你推薦幾家優質餐廳：

${[...n,...t].slice(0,5).map(o=>{const s=o.is_safe_store?"🛡️":"",u=o.has_member_discount?"⭐":"",_=o.is_partner_store?"🤝":"";return`🍽️ **${o.store_name}** ${s}${u}${_}
📍 ${o.address}
📞 ${o.phone}
🕒 ${o.business_hours}
💡 ${o.features}
${o.has_member_discount?"🎁 會員優惠":""}
${o.is_partner_store?"🤝 特約商家":""}`}).join(`

`)}

📍 **交通資訊：**
鄰近鳳山火車站，交通超便利的！

有什麼特別想吃的料理嗎？我可以為你詳細介紹～ 😊`}else if(e.includes("停車")||e.includes("交通"))c=`文山特區的停車和交通資訊：

🅿️ **停車資訊：**
• 公有停車場：每小時20元
• 路邊停車：每小時20元，限時3小時
• 商場停車：每小時15-20元

🚇 **交通方式：**
• 鳳山火車站：步行5分鐘
• 高雄捷運鳳山西站：步行10分鐘
• 公車：多條路線經過

需要更詳細的交通指引嗎？我對這裡超熟的！😊`;else if(e.includes("咖啡")||e.includes("咖啡廳")||e.includes("飲料"))c=`文山特區有很多優質咖啡廳！我為您推薦：

${d("咖啡廳").map(n=>{const t=n.is_safe_store?"🛡️":"",r=n.has_member_discount?"⭐":"";return`☕ **${n.store_name}** ${t}${r}
📍 ${n.address}
📞 ${n.phone}
🕒 ${n.business_hours}
💡 ${n.features}
${n.has_member_discount?"🎁 會員優惠":""}`}).join(`

`)}

需要了解特定咖啡廳的詳細資訊嗎？`;else if(e.includes("文具")||e.includes("辦公用品")||e.includes("學生用品"))c=`文山特區的文具用品店推薦：

${d("文具用品").map(n=>{const t=n.is_safe_store?"🛡️":"",r=n.has_member_discount?"⭐":"";return`📝 **${n.store_name}** ${t}${r}
📍 ${n.address}
📞 ${n.phone}
🕒 ${n.business_hours}
💡 ${n.features}
${n.has_member_discount?"🎁 會員優惠":""}`}).join(`

`)}

需要找特定文具用品嗎？`;else if(e.includes("服飾")||e.includes("衣服")||e.includes("服裝"))c=`文山特區的服飾店推薦：

${d("服飾").map(n=>{const t=n.is_safe_store?"🛡️":"",r=n.has_member_discount?"⭐":"";return`👕 **${n.store_name}** ${t}${r}
📍 ${n.address}
📞 ${n.phone}
🕒 ${n.business_hours}
💡 ${n.features}
${n.has_member_discount?"🎁 會員優惠":""}`}).join(`

`)}

需要找特定風格的服飾嗎？`;else if(e.includes("3C")||e.includes("家電")||e.includes("電子產品"))c=`文山特區的3C家電店推薦：

${d("3C家電").map(n=>{const t=n.is_safe_store?"🛡️":"",r=n.has_member_discount?"⭐":"";return`📱 **${n.store_name}** ${t}${r}
📍 ${n.address}
📞 ${n.phone}
🕒 ${n.business_hours}
💡 ${n.features}
${n.has_member_discount?"🎁 會員優惠":""}`}).join(`

`)}

需要找特定3C產品嗎？`;else if(e.includes("活動")||e.includes("市集")||e.includes("節慶"))c=`文山特區的活動資訊：

🎉 **目前活動：**
• 週末市集：每週六日，文山特區廣場
• 美食節：本月舉辦中，多家餐廳優惠
• 會員優惠：消費滿500送50

📅 **定期活動：**
• 文創市集：每月第一個週末
• 親子活動：每月第三個週日
• 節慶慶祝：春節、中秋等節日

想了解哪個活動的詳細資訊呢？`;else if(e.includes("商店")||e.includes("購物")||e.includes("買")||e.includes("推薦")||e.includes("哪裡有")){const n=f(["商店","購物","買","推薦","哪裡有","餐廳","咖啡","文具","服飾","3C","家電"].filter(s=>e.includes(s))),t=n.filter(s=>s.is_partner_store),r=n.filter(s=>!s.is_partner_store),o=[...t,...r].slice(0,5);o.length>0?c=`文山特區有很多優質商家！我為您推薦幾家：

${o.map(s=>{const u=s.is_safe_store?"🛡️":"",_=s.has_member_discount?"⭐":"",a=s.is_partner_store?"🤝":"";return`🏪 **${s.store_name}** ${u}${_}${a}
📍 ${s.address}
📞 ${s.phone}
🕒 ${s.business_hours}
💡 ${s.features}
${s.has_member_discount?"🎁 會員優惠":""}
${s.is_partner_store?"🤝 特約商家":""}`}).join(`

`)}

${n.length>5?`
還有 ${n.length-5} 家商家可以選擇！`:""}

需要了解特定商家的詳細資訊嗎？`:c=`文山特區的商店資訊：

🛍️ **主要商圈：**
• 文衡路商圈 - 服飾、生活用品
• 文濱路商圈 - 3C、家電
• 文龍路商圈 - 美食、咖啡廳

🏪 **特色商店：**
• 在地文創店 - 手作商品
• 傳統市場 - 新鮮蔬果
• 便利商店 - 24小時服務

需要找特定商品嗎？`}else c=`嘿！我是高文文，23歲的高雄女孩！文山特區的專屬客服助理～✨

我可以幫你介紹：
🍽️ 美食餐廳推薦
🛍️ 商店購物資訊  
🅿️ 交通停車指引
🎉 活動優惠資訊
📚 教育學習推薦

有什麼想知道的嗎？我對文山特區超熟的，很樂意為你服務！😊`;return{response:c,sessionId:l||crypto.randomUUID(),timestamp:new Date().toISOString()}}export{S as mockSendMessage};
//# sourceMappingURL=mockClaudeChat-BI3eXOlU.js.map
